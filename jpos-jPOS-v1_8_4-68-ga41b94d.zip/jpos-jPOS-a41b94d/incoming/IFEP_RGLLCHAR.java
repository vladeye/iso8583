package org.jpos.iso;

public class IFEP_RGLLCHAR extends IFEP_TTLLCHAR {

    String getDefaultID() {
        return "RG";
    }

}
