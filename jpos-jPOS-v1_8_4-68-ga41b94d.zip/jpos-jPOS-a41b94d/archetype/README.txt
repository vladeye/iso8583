In order to generate a jPOS application based on this archetype, you need to: 

    mvn install 

then, on another directory call:

    mvn archetype:generate -DarchetypeCatalog=local 

