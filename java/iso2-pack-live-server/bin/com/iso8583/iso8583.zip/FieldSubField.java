package com.iso8583;

import java.util.HashMap;

public class FieldSubField {
 public static void main(String[] args)
 {
	 HashMap< String, String> Hmap = new HashMap<String, String>();
	 Hmap.put("120.1", "Bitmap");
	 Hmap.put("120.2", "Card Token Number");
	 Hmap.put("120.3", "Account Type");
	 Hmap.put("120.4", "Name on Card");
	 Hmap.put("120.5", "Credit Card Type");
	 Hmap.put("120.6", "Card Issuer");
	 Hmap.put("120.7", "Card Nick Name");
	 Hmap.put("120.8", "Expiration Day");
	 Hmap.put("120.9", "Street ADDRESS");
	 Hmap.put("120.10", "CITY");
	 Hmap.put("120.11", "STATE CODE");
	 Hmap.put("120.12", "ZIP CODE");
	 Hmap.put("120.13", "Is favorite");
	 Hmap.put("120.14", "Card Token Number");
	 Hmap.put("120.15", "Account Type");
	 Hmap.put("120.16", "Name on Card");
	 Hmap.put("120.17", "Credit Card Type");
	 Hmap.put("120.18", "Card Issuer");
	 Hmap.put("120.19", "Card Nick Name");
	 Hmap.put("120.20", "Expiration Day");
	 Hmap.put("120.21", "Street ADDRESS");
	 Hmap.put("120.22", "CITY");
	 Hmap.put("120.23", "STATE CODE");
	 Hmap.put("120.24", "ZIP CODE");
	 Hmap.put("120.25", "Is favorite");
	 Hmap.put("120.26", "Card Token Number");
	 Hmap.put("120.27", "Account Type");
	 Hmap.put("120.28", "Name on Card");
	 Hmap.put("120.29", "Credit Card Type");
	 Hmap.put("120.30", "Card Issuer");
	 Hmap.put("120.31", "Card Nick Name");
	 Hmap.put("120.32", "Expiration Day");
	 Hmap.put("120.33", "Street ADDRESS");
	 Hmap.put("120.34", "CITY");
	 Hmap.put("120.35", "STATE CODE");
	 Hmap.put("120.36", "ZIP CODE");
	 Hmap.put("120.37", "Is favorite");
 }
}
